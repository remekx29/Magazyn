﻿namespace MagazynAPP.Utilities
{
    public class AppSettings
    {
        public string Secret { get; set; } = string.Empty;

    }
}
